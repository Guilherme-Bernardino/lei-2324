import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.control.Button;
import java.awt.event.ActionEvent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * Escreva uma descrição da classe MainMenu aqui.
 * 
 * @author (seu nome) 
 * @version (um número da versão ou uma data)
 */
public class MenuPane extends Scene
{
    
    private BorderPane root;
    
    public MenuPane(Stage primaryStage){
        super(new BorderPane(),500,500);
        root = new BorderPane();
        this.init(primaryStage);
        setRoot(root);
    }
    
    public void init(Stage primaryStage){
 
    }
}
