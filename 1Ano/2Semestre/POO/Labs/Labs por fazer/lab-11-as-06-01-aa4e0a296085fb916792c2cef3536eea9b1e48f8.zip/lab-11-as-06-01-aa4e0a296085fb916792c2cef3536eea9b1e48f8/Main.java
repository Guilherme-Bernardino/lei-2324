import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import java.util.Timer;
import java.util.TimerTask;
import javafx.scene.layout.VBox;
import javafx.scene.shape.*;
import javafx.scene.paint.Color;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.geometry.Pos;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import java.util.ArrayList;

public class Main extends Application{
    private Stage stage;
    
    @Override
    public void start(Stage stage)
    {
        stage.show();
    }
    
    private Scene getInitialScene(){
        Label welcomeLabel = new Label("Bem vindo ao jogo Color Guesser");
        welcomeLabel.setTranslateY(50);
        
        
        Label infoLabel = new Label("Clique em 'Start' para começar");
        
        
        Button btnStart = new Button("Start");
        btnStart.setTranslateY(-30);
        
        btnStart.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
                
            }
        });
        
        StackPane sp = new StackPane();
        
        sp.getChildren().addAll(welcomeLabel, infoLabel, btnStart);
        Scene scene = new Scene(sp, 500,500);
        scene.getStylesheets().addAll(this.getClass().getResource("styles/style.css").toExternalForm());
        
        stage.setTitle("No nivel 2 altere-me");
        
        return scene;
    }
    
    
}
