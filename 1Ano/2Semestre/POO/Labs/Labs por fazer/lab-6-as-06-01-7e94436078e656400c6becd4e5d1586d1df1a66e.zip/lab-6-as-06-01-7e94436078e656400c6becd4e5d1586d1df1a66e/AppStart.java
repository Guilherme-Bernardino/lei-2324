
/**
 * Main entry class
 *
 * @author POO
 * @version April '23
 */
public class AppStart
{
    public static void main(String[] args) {
        // TODO insert your logic here
    }
}
