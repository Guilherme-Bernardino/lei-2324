
/**
 *
 * @author POO
 * @version April '23
 */
public class Podcast
{
    private String title;
    
    public Podcast(String title) {
        this.title = title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getTitle() {
        return title;
    }
}
