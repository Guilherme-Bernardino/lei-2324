import java.util.ArrayList;
import java.util.HashSet;

public class CoffeeShop {

    private final HashSet<Member> members;
    private final ArrayList<Purchase> purchases;

    public CoffeeShop() {
        this.members = new HashSet<>();
        this.purchases = new ArrayList<>();
    }


}
