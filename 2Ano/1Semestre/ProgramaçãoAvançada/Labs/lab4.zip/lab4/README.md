# PT

## Programação Avançada 22/23

### Laboratório 4 (Avaliado)

### Objetivos:
* Utilização/manipulação do ADT Binary Search Tree para inteiros;
* Criação de testes unitários em JUnit;
* Implementação de métodos adicionais.

---

# EN

## Advanced Programming 22/23

### Lab 4 (Evaluated)

### Objectives:
* Usage/manipulation of ADT Binary Search Tree for integers;
* Creating of unit tests, using JUnit;
* Implementation of additional methods.
