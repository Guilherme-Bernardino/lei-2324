# PT

## Programação Avançada 22/23

### Laboratório 6 (Avaliado)

### Objetivos:
* Implementação do ADT Graph usando uma Lista de Adjacências;
* Desenvolvimento de testes unitários.

---

# EN

## Advanced Programming 22/23

### Lab 6 (Evaluated)

### Objectives:
* Implementation of ADT Graph using an Adjacency List;
* Development of unit tests.
