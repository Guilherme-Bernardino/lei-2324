# PT

## Programação Avançada 22/23

### Laboratório 7 (Tutorial)

### Objetivos:
* Aplicação do padrão de software Memento;
* Desenvolvimento de testes unitários.

---

# EN

## Advanced Programming 22/23

### Lab 7 (Tutorial)

### Objectives:
* Application of the Memento software pattern;
* Development of unit tests.
