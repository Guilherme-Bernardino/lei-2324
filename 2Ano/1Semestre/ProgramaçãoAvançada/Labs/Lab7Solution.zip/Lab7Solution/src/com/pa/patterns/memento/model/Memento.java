package com.pa.patterns.memento.model;

import java.util.List;

public interface Memento {
    String getDescription();
}
