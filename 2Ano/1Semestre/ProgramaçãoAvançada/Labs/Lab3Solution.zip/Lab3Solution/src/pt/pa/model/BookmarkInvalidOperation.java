/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package pt.pa.model;
/**
 *
 * @author brunomnsilva
 */
public class BookmarkInvalidOperation extends RuntimeException {

    public BookmarkInvalidOperation(String message) {
        super(message);
    }
    
}
