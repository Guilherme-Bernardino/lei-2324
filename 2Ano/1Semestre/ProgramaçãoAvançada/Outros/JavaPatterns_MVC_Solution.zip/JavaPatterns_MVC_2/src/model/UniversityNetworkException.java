package model;

public class UniversityNetworkException extends RuntimeException {

    public UniversityNetworkException() {
    }

    public UniversityNetworkException(String message) {
        super(message);
    }

}
