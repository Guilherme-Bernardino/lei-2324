#Exercício

Aplique a Técnica **Extract Class** de forma a fazer uma correta separação das responsabilidades.
No fim deverá ter 3 classes:
- `AppMainCalculator` - Classe responsável por lançar a aplicação JAVAFX;
- `CalculatorUI` - Classe responsável por implementar a interação com o utilizador;
- `Calculator` - Classe responsável por implementar a lógica do "**Calculator**".
