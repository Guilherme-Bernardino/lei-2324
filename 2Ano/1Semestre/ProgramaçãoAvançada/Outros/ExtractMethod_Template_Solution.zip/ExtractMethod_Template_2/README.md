#Exercício

Aplique a técnica de Refactoring **Extract Method**, de forma a remover o **BAD SMELL** Duplicated Code 